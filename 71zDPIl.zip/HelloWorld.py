class HelloWorld:
  def __init__(self):
    self.message = 'Hello world!'
